---
name: Feature Request
labels: feature
about: RFC and ideas for new features and improvements
---

# Feature Request

<!-- First, thank you for making a request. That takes time and we appreciate that! -->
 
## Diff 

<!-- Use diff here in Markdown: https://stackoverflow.com/a/40883538/1348344 -->

```diff
-$value = $value + 5;
+$value += 5;
```
