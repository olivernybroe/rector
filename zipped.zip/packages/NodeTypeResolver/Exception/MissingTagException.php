<?php

declare(strict_types=1);

namespace Rector\NodeTypeResolver\Exception;

use Exception;

final class MissingTagException extends Exception
{
}
